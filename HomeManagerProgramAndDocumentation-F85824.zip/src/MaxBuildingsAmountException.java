

public class MaxBuildingsAmountException extends Throwable
{
    public MaxBuildingsAmountException(String s)
    {
        super(s);
    }
}
